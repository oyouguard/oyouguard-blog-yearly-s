오유가드 × 황금부엉이 — 선택형 장문 해석 (연도/월별·양력/음력, 무료)

특징
- 연도 선택 + 월별 운세 각 5~6문장
- 양력/음력 선택, 결과에 달력 종류 표기
- 선택한 항목만 장문 출력 (재물·인연·건강·자녀)
- 이름 포함, 정중하고 예의 바른 문체
- 굿즈는 가격 없이 상징 의미만 안내

배포 (Netlify + GitHub)
1) 이 폴더 구조 그대로 GitHub 저장소에 업로드
2) Netlify → Add new site → Import an existing project
3) GitHub 저장소 선택, Build command 공란 / Publish directory "/"
4) 배포 후 주소 뒤에 #/free 를 붙여 사용
