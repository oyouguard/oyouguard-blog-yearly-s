// Helpers
function mulberry32(a){return function(){var t=a+=0x6D2B79F5;t=Math.imul(t^t>>>15, t|1);t^=t+Math.imul(t^t>>>7, t|61);return ((t^t>>>14)>>>0)/4294967296}}
function $(sel, root=document){return root.querySelector(sel)}
const App = $("#app");

// Router
const routes = { "/free": renderFree, "/fortune": renderFortune, "/about": renderAbout };
function router(){ const hash = location.hash.replace("#","") || "/free"; (routes[hash]||renderFree)(); }
window.addEventListener("hashchange", router); window.addEventListener("load", router);

// Utilities
function calcAge(birth){
  if(!birth) return null; const b = new Date(birth); if(Number.isNaN(b.getTime())) return null;
  const now = new Date(); let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth(); if(m < 0 || (m === 0 && now.getDate() < b.getDate())) age--; return age;
}
function inferElement(birth, time, gender){
  const ymd = (birth||"").replace(/-/g,""); const y = Number(ymd.slice(0,4)||0);
  const m = Number(ymd.slice(4,6)||0); const d = Number(ymd.slice(6,8)||0);
  const hour = (()=>{ const mm = /(\d{1,2})/.exec(time||""); return mm? Math.max(0,Math.min(23,parseInt(mm[1],10))) : 12 })();
  let seed = y*10000 + m*100 + d + hour; if((gender||"").includes("여")) seed += 7;
  const idx = Math.abs(seed)%5; return ["금","수","화","목","토"][idx];
}
function goodsByElement(el){ return GOODS.filter(g=>g.element===el).slice(0,2); }

// Monthly generator (5~6 sentences per month, practical style)
const MONTHS = ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"];
const BANK = {
  wealth: [
    "지출 구조를 다시 점검하시면 작은 절약이 큰 여유로 이어집니다.",
    "계약과 정산은 서두르지 말고, 마지막 검토 한 번으로 실수를 줄이십시오.",
    "수입 다변화의 단서를 기록해 두시면, 분기마다 개선점을 찾을 수 있습니다.",
    "불필요한 정기 결제를 정리하면 현금 흐름이 안정됩니다.",
    "가족이나 지인과의 금전 거래는 한도와 기한을 분명히 하십시오.",
    "새로운 투자는 분산과 분할의 원칙을 지키는 것이 안전합니다.",
    "세금·보험 등 보이지 않는 비용이 실적을 좌우하니 달마다 확인하십시오.",
    "작은 수익원을 더하는 보완 전략이 실질적인 실익을 만듭니다.",
    "거래처 재정비로 단가 개선이나 조건 조정의 여지가 생깁니다.",
    "현금성 예비자금을 확보해 돌발 상황에 대비하시길 권합니다.",
    "문서·보증 관련 위험은 서면 기준으로 관리하면 줄어듭니다.",
    "월 말에 간단한 결산 노트를 작성하면 다음 달 실수가 줄어듭니다."
  ],
  relation: [
    "약속과 기한을 지키는 태도가 신뢰를 크게 높입니다.",
    "작은 오해는 빠르게 풀어야 큰 갈등으로 번지지 않습니다.",
    "오래 알던 인연에서 뜻밖의 제안이 들어올 수 있습니다.",
    "새로운 모임에서는 경청과 기록이 큰 힘이 됩니다.",
    "일과 사생활의 경계를 정하면 마음이 한결 가벼워집니다.",
    "감사의 표현을 구체적으로 전하면 관계의 온기가 커집니다.",
    "협업에서는 역할과 권한, 성과 배분을 사전에 합의하십시오.",
    "휴식과 정리가 필요할 때는 속도를 잠시 낮추는 것이 좋습니다.",
    "필요한 부탁은 명확하게, 거절은 정중하게 표현해도 괜찮습니다.",
    "갈등 시에는 감정보다 사실과 해결책에 집중하십시오.",
    "작은 배려가 긴 신뢰로 이어지는 시기입니다.",
    "먼저 안부를 묻는 연락이 관계의 문을 다시 엽니다."
  ],
  health: [
    "수면 시간과 기상 시간을 일정하게 유지하면 컨디션이 안정됩니다.",
    "순환과 체온 관리를 위해 가벼운 유산소 운동을 권합니다.",
    "과로의 전조 신호를 기록해두면 회복이 빨라집니다.",
    "소화와 수분 섭취에 유의하시고 식사 속도를 조금 늦춰 보십시오.",
    "코어 강화와 스트레칭으로 자세 균형을 잡아 주십시오.",
    "검진 일정을 미리 달력에 넣어두면 실천률이 높아집니다.",
    "짧은 산책과 호흡 루틴이 긴장을 낮추는 데 도움이 됩니다.",
    "업무 강도가 높은 날에는 중간 휴식을 계획하십시오.",
    "회복 탄력이 커지는 시기에는 작은 습관을 붙이기 좋습니다.",
    "마음의 균형을 위해 감사 일기를 시도해 보시는 것도 좋습니다.",
    "가벼운 근력 운동이 전반적인 피로도를 낮춰 줍니다.",
    "밤늦은 카페인을 줄이면 수면의 질이 좋아집니다."
  ],
  children: [
    "자녀의 강점을 발견하고 그 과정을 칭찬해 주십시오.",
    "진로·학업과 관련한 선택은 충분한 대화와 자료 공유가 필요합니다.",
    "독립과 협력의 균형을 조율하는 시기입니다.",
    "실패 경험을 배움으로 전환하는 시각이 큰 도움이 됩니다.",
    "가정 내 역할 분담을 가볍게 조정하면 생활 리듬이 안정됩니다.",
    "정서적 지지와 현실적인 조언을 함께 제공해 주세요.",
    "새로운 시도를 응원하되 기준과 책임을 분명히 하십시오.",
    "가족 일정과 목표를 함께 점검하면 공동의 리듬이 만들어집니다.",
    "갈등이 생기면 시간·장소·주제를 정해 차분히 대화하세요.",
    "중요 결정은 하루 숙성 후 확정하면 실수가 줄어듭니다.",
    "작은 성취를 함께 축하하면 도전 의지가 커집니다.",
    "관심사 기반의 활동이 자존감과 관계를 동시에 키웁니다."
  ]
};
function monthlyParagraphs(topic, year, seedBase){
  const bank = BANK[topic] || BANK.wealth;
  let html = "";
  for(let mi=0; mi<12; mi++){
    const monthSeed = year*100 + seedBase + (mi+1);
    const r2 = mulberry32(monthSeed);
    const idxs = bank.map((_,i)=>i).sort((a,b)=>r2()-0.5);
    const n = 5 + Math.floor(r2()*2); // 5 or 6
    const lines = idxs.slice(0,n).map(i=>bank[i]);
    html += `<div class="month"><h4>${year}년 ${MONTHS[mi]}</h4>${lines.map(s=>`<p>${s}</p>`).join("")}</div>`;
  }
  return html;
}

// Section helpers
function inferCalendarText(calendar, birth){
  if(!birth) return ""; // 달 변환은 단순 표기만
  return `입력하신 생년월일(달력: ${calendar||"양력"})을 기준으로, `;
}
function inferElementText(el){
  const goods = goodsByElement(el);
  const gtext = goods.map(g=>`‘${g.name}’ — ${g.desc}`).join(" ");
  return `오행 관점에서 부족한 기운은 ‘${el}’로 보입니다. ${gtext || "생활 공간의 정리 정돈과 자연 소재를 활용해 중심을 다지셔도 좋겠습니다."}`;
}
function sectionAnnualIntro(topic, ctx){
  const {name, year} = ctx;
  const label = {wealth:"재물운", relation:"인연운", health:"건강운", children:"자녀운"}[topic] || "운세";
  return `<div class="card"><h3>◆ ${label}</h3>
  <p>${name||"귀하"}님의 ${year}년 ${label}은 상반기에는 기반을 다지고 하반기에는 확장을 준비하는 흐름으로 읽힙니다. 중요한 일ほど ‘계획→시행→점검’의 순환을 짧게 가져가시면 안정과 성장이 함께합니다.</p>
  <p>특히 중간 분기에는 실행 계획을 재점검하시고, 연말에는 정산과 결산을 통해 다음 해의 방향성을 구체화하시길 권합니다.</p>`;
}
function sectionAnnualOutro(el){ return `<p>${inferElementText(el)}</p></div>`; }

function secWealth(ctx){ return sectionAnnualIntro("wealth", ctx) + `<div class="month-list">${monthlyParagraphs("wealth", ctx.year, 701)}</div>` + sectionAnnualOutro(ctx.element); }
function secRelation(ctx){ return sectionAnnualIntro("relation", ctx) + `<div class="month-list">${monthlyParagraphs("relation", ctx.year, 702)}</div>` + sectionAnnualOutro(ctx.element); }
function secHealth(ctx){ return sectionAnnualIntro("health", ctx) + `<div class="month-list">${monthlyParagraphs("health", ctx.year, 703)}</div>` + sectionAnnualOutro(ctx.element) + `<p class="small">※ 건강 관련 결정은 반드시 의료 전문가의 진단과 상담을 우선하시길 권합니다.</p>`; }
function secChildren(ctx){ return sectionAnnualIntro("children", ctx) + `<div class="month-list">${monthlyParagraphs("children", ctx.year, 704)}</div>` + sectionAnnualOutro(ctx.element); }

function longReading({name, gender, birth, time, selections, year, calendar}){
  const age = calcAge(birth); const element = inferElement(birth, time, gender);
  const head = `
    <p>안녕하세요, ${name||"귀하"}님.</p>
    <p>${inferCalendarText(calendar, birth)}요청하신 연도와 선택하신 주제에 대하여, 월별 흐름까지 정중하고 자세히 안내드립니다. 본 해석은 참고용이며, 생활과 건강을 최우선으로 삼아 계획을 세워 주시길 바랍니다.</p>
  `;
  const ctx = {name, age, year, element};
  let body = "";
  if(selections.includes("wealth")) body += secWealth(ctx);
  if(selections.includes("relation")) body += secRelation(ctx);
  if(selections.includes("health")) body += secHealth(ctx);
  if(selections.includes("children")) body += secChildren(ctx);
  const tail = `<p>이 해석이 ${name||"귀하"}님의 걸음에 작은 등불이 되기를 진심으로 바랍니다. 감사합니다.</p>`;
  return head + body + tail;
}

// Fortune (simple)
function renderFortune(){
  const today = new Date(); const ymd = Number(today.toISOString().slice(0,10).replace(/-/g,"")); const rnd = mulberry32(ymd);
  const messages = [
    "초심으로 돌아가면 길이 열립니다.","만남 속에 기회가 있습니다. 귀인을 만나세요.","작은 지출을 줄이면 큰 재물이 들어옵니다.",
    "감정보다 데이터로 판단하면 손실을 줄입니다.","서쪽 방위에서 좋은 소식이 있습니다.","오전보다 오후의 운이 강합니다."
  ];
  const advice = messages[Math.floor(rnd()*messages.length)];
  App.innerHTML = `<section class="card"><h2>🔮 오늘의 운세</h2><blockquote>${advice}</blockquote><p class="small">정밀한 장문 해석은 <a href="#/free">무료 장문 해석</a>에서 확인하실 수 있습니다.</p></section>`;
}

// UI
function renderFree(){
  const now = new Date(); const startYear = now.getFullYear();
  const years = Array.from({length:6}, (_,i)=>startYear+i); // 현재연도~+5년
  App.innerHTML = `
    <section class="card">
      <h2>📖 무료 장문 해석</h2>
      <p class="small">궁금한 항목만 선택하시고, 기준이 될 연도와 달력을 지정하시면 해당 연도의 <strong>1~12월 월별 흐름(각 5~6문장)</strong>까지 정중하고 자세히 안내드립니다.</p>
      <form id="freeForm" class="grid grid-2">
        <div>
          <label>이름</label>
          <input class="input" name="name" required placeholder="홍길동">
        </div>
        <div>
          <label>성별</label>
          <select class="input" name="gender">
            <option value="남">남</option>
            <option value="여">여</option>
          </select>
        </div>
        <div>
          <label>달력 선택</label>
          <div class="radio">
            <label><input type="radio" name="calendar" value="양력" checked> 양력</label>
            <label><input type="radio" name="calendar" value="음력"> 음력</label>
          </div>
        </div>
        <div>
          <label>생년월일</label>
          <input class="input" name="birth" type="date" required>
        </div>
        <div>
          <label>태어난 시간</label>
          <input class="input" name="time" placeholder="예: 21:00 또는 모름">
        </div>
        <div style="grid-column:1/-1">
          <label>궁금한 항목 (다중 선택 가능)</label>
          <div class="grid" style="grid-template-columns: repeat(4, minmax(0, 1fr)); gap:10px">
            <label class="checkbox"><input type="checkbox" name="topics" value="wealth"> 재물운</label>
            <label class="checkbox"><input type="checkbox" name="topics" value="relation"> 인연운</label>
            <label class="checkbox"><input type="checkbox" name="topics" value="health"> 건강운</label>
            <label class="checkbox"><input type="checkbox" name="topics" value="children"> 자녀운</label>
          </div>
          <p class="small">※ 선택하신 항목만 결과에 표시됩니다.</p>
        </div>
        <div>
          <label>해석 기준 연도</label>
          <select class="input" name="year">
            ${years.map(y=>`<option value="${y}">${y}</option>`).join("")}
          </select>
        </div>
        <div style="display:flex;gap:8px;align-items:flex-end">
          <button class="primary" type="submit">신청하기</button>
          <button class="ghost" type="button" id="resetBtn">초기화</button>
        </div>
      </form>
    </section>
    <section id="resultWrap" class="card" style="display:none"></section>
  `;

  $("#resetBtn").addEventListener("click", ()=>{ $("#freeForm").reset(); const r = $("#resultWrap"); r.style.display="none"; r.innerHTML=""; });

  document.getElementById("freeForm").addEventListener("submit", (e)=>{
    e.preventDefault();
    const fd = new FormData(e.target);
    const name = fd.get("name")||""; const gender = fd.get("gender")||"";
    const birth = fd.get("birth")||""; const time = fd.get("time")||"";
    const year = parseInt(fd.get("year"),10); const calendar = fd.get("calendar")||"양력";
    const selections = Array.from(document.querySelectorAll('input[name="topics"]:checked')).map(el=>el.value);
    if(selections.length===0){ alert("궁금한 항목을 최소 1개 이상 선택해 주세요."); return; }
    const html = longReading({name, gender, birth, time, selections, year, calendar});
    const r = document.getElementById("resultWrap");
    r.style.display = "block"; r.innerHTML = `<h3>🔍 해석</h3>${html}`; r.scrollIntoView({behavior:"smooth"});
  });
}

// About
function renderAbout(){
  App.innerHTML = `
    <section class="card">
      <h2>✍️ 오유가드의 이야기</h2>
      <p>선택하신 주제만 깊이 있게 다루는 정중한 장문 해석을 지향합니다. 가격 정보나 구매 유도 없이, 상징의 의미만을 담아 안내합니다.</p>
      <p class="small">※ 본 해석은 참고용이며, 건강·법률·재무 등 중요한 결정은 전문가와 상의하시길 권합니다.</p>
    </section>
  `;
}
