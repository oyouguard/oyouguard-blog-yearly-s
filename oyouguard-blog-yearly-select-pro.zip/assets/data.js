// Symbolic goods (no prices)
const GOODS = [
  { id: "g1", name: "황금 부엉이", element: "금", desc: "지혜와 재물의 수호 상징. 현관 오른쪽 또는 책상 위에 두면 좋습니다."},
  { id: "g2", name: "청색 행운 팔찌", element: "수", desc: "유연함·소통의 기운을 돕습니다. 가까이 지니면 인연운이 안정됩니다."},
  { id: "g3", name: "옥(玉) 원석 키링", element: "목", desc: "성장과 확장의 기운을 북돋우는 상징입니다."},
  { id: "g4", name: "붉은 향초", element: "화", desc: "열정과 추진력의 불씨를 지피는 상징입니다."},
  { id: "g5", name: "황토/석재 소품", element: "토", desc: "안정과 중심을 돕는 상징. 서재나 작업 공간에 두면 좋습니다."}
];
